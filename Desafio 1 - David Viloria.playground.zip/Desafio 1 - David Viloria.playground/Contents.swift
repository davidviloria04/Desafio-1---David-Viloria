import UIKit

typealias Direction = (neighborhood: String,
                       city: String,
                       region: String,
                       street: [String:Any?],
                       country: String,
                       postalCode: Int,
                       floor: Int?,
                       apartment: Int?,
                       tower: Int?)

let firstPerson = Direction(neighborhood: "Nueva Granada",
                            city: "Barranquilla",
                            region: "Caribe",
                            street: ["nombreDeCalle": "Calle 68",
                                    "numero": 27,
                                    "entreCalle1": "Calle 67",
                                    "entreCalle2": "Calle 68 B"],
                            country: "Colombia",
                            postalCode: 080012,
                            floor: 2,
                            apartment: nil,
                            tower: nil
                            
)

let secondPerson = Direction(neighborhood: "San Felipe",
                             city: "Bogota",
                             region: "Andina",
                             street: ["nombreDeCalle": "20 B",
                                     "numero": 75,
                                     "entreCalle1": "75",
                                     "entreCalle2": "76"],
                             country: "Colombia",
                             postalCode: 094567,
                             floor: 2,
                             apartment: 1,
                             tower: nil
                             
)


let thirdPerson = Direction(neighborhood: "La Campiña",
                            city: "Cartagena",
                            region: "Caribe",
                            street: ["nombreDeCalle": "La lengua",
                                    "numero": 45,
                                    "entreCalle1": "Caracoles",
                                    "entreCalle2": "Los Abastos"],
                            country: "Colombia",
                            postalCode: 598745,
                            floor: 14,
                            apartment: 1408,
                            tower: 6
                            
)


func formattedAddress (direction: Direction) -> String {
    let completeDirection = "La dirección es \(direction)"
    return completeDirection
}


func internalAddress (direction: Direction) -> String {
    if  let floor = direction.floor,
        let tower = direction.tower,
        let apartment = direction.apartment {
        
        return "Torre \(tower) piso \(floor) y el apartamento es el \(apartment)"
    }
    else {
        return "Esta direccion es de una casa popular o es invalidad"
    }
}
